﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovidProject.DataStructues
{
    class Patient_Data
    {
        private Dictionary<int, Patient> p_data_illness = new Dictionary<int, Patient>();

        private static Patient_Data p1;

        private Patient_Data()
        {

        }

        private static Patient_Data pdetails()
        {
            if (p1 == null)

                p1 = new Patient_Data();  //Singleton Object
            return p1;

        }

        internal void Setpatientdata(int v, object p_data_illness)
        {
            throw new NotImplementedException();
        }

        public void Setpatientdata(Dictionary<int, Patient> p_data_illness)
         {
            this.p_data_illness = p_data_illness;


        }



        public Dictionary<int, Patient> Getpatientdata()
        {
            return p_data_illness;
        }
    }
}
