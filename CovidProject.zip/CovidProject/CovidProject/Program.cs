﻿using CovidProject.DataStructues; //Proj is in COvid Folder but Class is in Data STructures folder so use this namespace.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovidProject
{
    class Program
    {
        private static object p_data_illness;

        static void Main(string[] args)
        {
            Patient p = new Patient();
            Patient_Data pd = new Patient_Data();

            //no method name exists.
            // public static Patient_Data

            Illness i = new Illness();

            //Add data to Dictionary

           








    p.Setpatient_ID(100);
            p.Setpatient_ID(101);
            p.Setpatient_ID(102);
            p.Setpatient_ID(103);
            p.Setpatient_ID(104);
            p.Setpatient_ID(105);

            p.Setpatient_age(10);
            p.Setpatient_age(40);
            p.Setpatient_age(22);
            p.Setpatient_age(55);
            p.Setpatient_age(33);

            p.Setpatient_address(17);
            p.Setpatient_address(15);
            p.Setpatient_address(8);
            p.Setpatient_address(9);
            p.Setpatient_address(2);

            p.Setpatient_bloodgroup("O");
            p.Setpatient_bloodgroup("B");
            p.Setpatient_bloodgroup("A");
            p.Setpatient_bloodgroup("A+");
            p.Setpatient_bloodgroup("AB");

            p.Setpatient_City("Bglr");
            p.Setpatient_City("Goa");
            p.Setpatient_City("Mysore");
            p.Setpatient_City("Delhi");
            p.Setpatient_City("Bglr");

            p.Setpatient_Name("Rahul");
            p.Setpatient_Name("John");
            p.Setpatient_Name("Raj");
            p.Setpatient_Name("Minuu");
            p.Setpatient_Name("Radha");

            p.Setpatient_phone(767828678);
            p.Setpatient_phone(767838678);
            p.Setpatient_phone(767828678);
            p.Setpatient_phone(767818678);
            p.Setpatient_phone(767848678);

            // Just One record need to created.
            p.Setpatient_illness("Cold");












        }

    }

}

//Other Programs***********************************************************************

        // enum Week { Monday,Tuesday,Wed,}
        // static void Main(string[] args)
       // {
            ////Enum*******************************************************


            //int count = (int)Week.Monday;

            //Console.WriteLine(count);
            //var values = Enum.GetValues(typeof(Week));
            //foreach(var individual in values)
            //{
            //    Console.WriteLine(individual); //Print only values
            //}
            
            
            
            
            
            //********************************************************

            //Nullable Types :

            //bool? covidresults = null; //if u know there could be null i/p than use this ie person has not tested .

            //if(covidresults==true)
            //{
            //    Console.WriteLine("Positive");

            //}
            //else if(covidresults==false)
            //{
            //    Console.WriteLine("Negative");
            //}
            //else
            //{
            //    Console.WriteLine("Not tested");
            //}

//*******************************************************************************
            ////Here u have multiple string OBjects
            //// string a = "A";
            //string a = " World is beautiful";
            //string b = "B";

            //a = a + b;
            //Console.WriteLine(a);

            ////Use StringBuilder

            //StringBuilder s = new StringBuilder(a);

            //s.Append("C");
            //s.Remove(0, 2);
            //s.Replace("How", "Is");
            //s.Insert(0, "Test **");

            //Console.WriteLine(s);



